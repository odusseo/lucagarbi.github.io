
from functions import w_mean,chi2,linear_regression_AB,random_momentum,random_position
from real_main import mass
