#!/usr/bin/env python3

from real_main import parte1
def main():
    parte1()

if __name__ == '__main__':
    main()
